Premium FX V4 source patch
Run in Codespaces repository root:
python3 /tmp/fx_v4/install.py
Changes PremiumScreen.java only. OverlayService.java and price acquisition unchanged.
The reference image is a concept; this patch improves alignment, glow and spacing but is NOT pixel-identical.
The patch makes a backup at PremiumScreen.java.v3backup (do not commit backup).
