from pathlib import Path
import re, shutil
p=Path('app/src/main/java/com/almuhandis/eurusdoverlay/PremiumScreen.java')
s=p.read_text()
if 'V4_REFINED' in s:
 print('Already installed');exit()
shutil.copy2(p,p.with_suffix('.java.v3backup'))
s=s.replace('public final class PremiumScreen {','public final class PremiumScreen { // V4_REFINED')
s=s.replace('root.setPadding(d(15),d(19),d(15),d(27))','root.setPadding(d(15),d(34),d(15),d(27))')
s=s.replace('root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(root);','root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);scroll.addView(root);')
s=s.replace('space(root,17);\n    Hero hero','space(root,24);\n    Hero hero')
s=s.replace('root.addView(hero,lp(-1,151))','root.addView(hero,lp(-1,162))')
s=s.replace('space(root,18);','space(root,24);')
s=s.replace('section.addView(eye,lp(43,43));','section.addView(eye,lp(43,43));')
s=s.replace('space(root,13);\n    LinearLayout card','space(root,23);\n    LinearLayout card')
s=s.replace('card.setPadding(d(10),d(15),d(10),d(12))','card.setPadding(d(13),d(18),d(13),d(15))')
s=s.replace('pairTitle.setGravity(Gravity.CENTER);','pairTitle.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);')
s=s.replace('pairSub.setGravity(Gravity.CENTER);','pairSub.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);')
s=s.replace('pair(card,"🇪🇺"','pair(card,"🇪🇺"')
start=s.index('  private static void pair(')
end=s.index('  private static void action(',start)
s=s[:start]+'''  private static void pair(LinearLayout target,String f1,String f2,String code,String label,String key,boolean def,Actions actions){
    // RTL visual order: drag handle, circular flag badges, names, toggle at right.
    LinearLayout row=horizontal();row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    row.setPadding(d(10),0,d(10),0);
    row.setBackground(gradient(new int[]{0xff07182c,0xff061326},16,0xff253b57));
    LinearLayout.LayoutParams rp=lp(-1,67);rp.bottomMargin=d(8);target.addView(row,rp);
    TextView drag=t("⠿",20,0xff7185a1,false);drag.setGravity(Gravity.CENTER);row.addView(drag,lp(26,-1));
    TextView flags=t(f1+" "+f2,22,WHITE,false);flags.setGravity(Gravity.CENTER);row.addView(flags,lp(91,-1));
    LinearLayout names=vertical();names.setGravity(Gravity.CENTER_VERTICAL);
    row.addView(names,new LinearLayout.LayoutParams(0,-1,1));
    TextView main=t(code,16,WHITE,true);main.setTextDirection(View.TEXT_DIRECTION_LTR);names.addView(main);
    TextView minor=t(label,11,SUB,false);names.addView(minor);
    Toggle toggle=new Toggle(a,prefs.getBoolean(key,def));row.addView(toggle,lp(62,40));
    toggle.setOnClickListener(v->{toggle.enabled=!toggle.enabled;toggle.invalidate();prefs.edit().putBoolean(key,toggle.enabled).apply();actions.changed();});
    row.setOnClickListener(v->toggle.performClick());
  }
''' + s[end:]
# Make the top icon placement respect reference left globe/right settings
s=s.replace('icon(top,"⚙",()->actions.battery());','icon(top,"◎",()->actions.source());')
s=s.replace('icon(top,"◎",()->actions.source());\n    TextView sub=', 'icon(top,"⚙",()->actions.battery());\n    TextView sub=')
# Hero paint: richer dark-glass base and halo, same true decorative preview disclaimer
s=s.replace('new int[]{0xff15365b,0xff06162b,0xff09284d}','new int[]{0xff102a4b,0xff030b1a,0xff071c34}')
s=s.replace('0xff257bff','0xff227fff')
s=s.replace('0x77338aff','0x99338aff')
s=s.replace('0x293d8ac6','0x354f9dce')
s=s.replace('String[] flags={"🇪🇺  🇺🇸","🇺🇸  🇪🇬","🇺🇸  🇮🇱"}','String[] flags={"🇪🇺  🇺🇸","🇺🇸  🇪🇬","🇺🇸  🇮🇱"}')
s=s.replace('float left=d(23),base=d(47),step=d(37)','float left=d(20),base=d(49),step=d(42)')
s=s.replace('w*.30f,y,15','w*.32f,y,15').replace('w*.66f,y,18','w*.69f,y,18')
# status bar dark text off, prevent transparent system chrome
s=s.replace('a.getWindow().setStatusBarColor(BG);a.getWindow().setNavigationBarColor(BG);','a.getWindow().setStatusBarColor(BG);a.getWindow().setNavigationBarColor(BG);a.getWindow().getDecorView().setSystemUiVisibility(0);')
p.write_text(s)
print('Installed V4 UI patch:',p)
