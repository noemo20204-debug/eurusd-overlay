#!/usr/bin/env python3
"""Apply Premium UI v2 to the current Android Java repository, preserving service code."""
from pathlib import Path
import re, shutil, urllib.request
root=Path.cwd()
main=root/'app/src/main/java/com/almuhandis/eurusdoverlay/MainActivity.java'
if not main.exists(): raise SystemExit('Run from eurusd-overlay project root')
s=main.read_text()
pattern=r'(?m)^    private void buildUi\(\) \{'
m=re.search(pattern,s)
if not m: raise SystemExit('Cannot find buildUi; project version differs. No files changed.')
start=m.start(); brace=s.index('{',m.start()); level=1; pos=brace+1
while level:
    if s[pos]=='{':level+=1
    elif s[pos]=='}':level-=1
    pos+=1
replacement='''    private void buildUi() {
        status = PremiumScreen.render(this, new PremiumScreen.Actions() {
            @Override public void changed() { refreshRunningOverlay(); refreshStatus(); }
            @Override public void start() { ensurePermissionAndStart(); }
            @Override public void stop() { stopOverlay(); }
            @Override public void battery() {
                try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()))); }
                catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            }
            @Override public void source() { startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://sa.investing.com/currencies/eur-usd"))); }
        });
        refreshStatus();
    }'''
s=s[:start]+replacement+s[pos:]
# Source currently has an earlier design; no change to service, permission or preference behavior.
assets=root/'app/src/main/assets/fonts';assets.mkdir(parents=True,exist_ok=True)
font_urls={
 'Cairo-Regular.ttf':'https://raw.githubusercontent.com/google/fonts/main/ofl/cairo/Cairo%5Bslnt%2Cwght%5D.ttf',
 'Cairo-Bold.ttf':'https://raw.githubusercontent.com/google/fonts/main/ofl/cairo/Cairo%5Bslnt%2Cwght%5D.ttf'
}
# Font must be present before changing code; if download fails, stop safely.
for filename,url in font_urls.items():
    dest=assets/filename
    if not dest.exists():
        try:
            print('Downloading Cairo font:',filename)
            urllib.request.urlretrieve(url,dest)
        except Exception as e:
            raise SystemExit('Cairo download failed; source code was not changed: '+str(e))
shutil.copy2(main,main.with_suffix('.java.bak'))
main.write_text(s)
shutil.copy2(Path(__file__).with_name('PremiumScreen.java'),main.with_name('PremiumScreen.java'))
print('Premium UI v2 installed. Original MainActivity saved as .java.bak')
