package com.almuhandis.eurusdoverlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OverlayService extends Service {
    public static final String SOURCE_URL = "https://sa.investing.com/currencies/eur-usd";
    public static final String SOURCE_USDEGP_URL = "https://sa.investing.com/currencies/usd-egp";

    private static final String CHANNEL_ID = "fx_overlay_channel";
    private static final int NOTIFICATION_ID = 10124;
    private static final String PREFS = "overlay_prefs";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(2);

    private WindowManager wm;
    private WindowManager.LayoutParams overlayParams;
    private LinearLayout overlay;

    private TextView eurPriceView;
    private TextView egpPriceView;

    private WebView eurWebView;
    private WebView egpWebView;

    private String lastEurPrice = null;
    private String lastEgpPrice = null;

    private long lastEurWebPriceAt = 0L;
    private long lastEgpWebPriceAt = 0L;
    private long lastEurHttpAttemptAt = 0L;
    private long lastEgpHttpAttemptAt = 0L;

    private boolean destroyed = false;

    private final Runnable pollJs = new Runnable() {
        @Override public void run() {
            if (destroyed) return;

            pollWebView(eurWebView, true);
            pollWebView(egpWebView, false);

            long now = System.currentTimeMillis();

            if (now - lastEurWebPriceAt > 9000 && now - lastEurHttpAttemptAt > 10000) {
                lastEurHttpAttemptAt = now;
                fetchViaHttpFallback(SOURCE_URL, true);
            }

            if (now - lastEgpWebPriceAt > 9000 && now - lastEgpHttpAttemptAt > 10000) {
                lastEgpHttpAttemptAt = now;
                fetchViaHttpFallback(SOURCE_USDEGP_URL, false);
            }

            main.postDelayed(this, 900);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        destroyed = false;

        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification("جاري جلب الأسعار…"));

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createOverlay();

        eurWebView = createHiddenWebView(SOURCE_URL);
        egpWebView = createHiddenWebView(SOURCE_USDEGP_URL);

        main.postDelayed(pollJs, 2800);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("enabled", true).apply();
        return START_STICKY;
    }

    private void createOverlay() {
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.HORIZONTAL);
        overlay.setGravity(Gravity.CENTER_VERTICAL);
        overlay.setPadding(dp(8), dp(4), dp(8), dp(4));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(230, 13, 17, 22));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Color.argb(115, 255, 255, 255));
        overlay.setBackground(bg);
        overlay.setElevation(dp(8));

        TextView eurLabel = label("EUR/USD");
        overlay.addView(eurLabel);

        TextView eurSpacer = spacer(" ");
        overlay.addView(eurSpacer);

        eurPriceView = priceText("—.————");
        overlay.addView(eurPriceView);

        TextView divider = spacer("   |   ");
        divider.setTextColor(Color.rgb(125, 135, 150));
        overlay.addView(divider);

        TextView egpLabel = label("USD/EGP");
        overlay.addView(egpLabel);

        TextView egpSpacer = spacer(" ");
        overlay.addView(egpSpacer);

        egpPriceView = priceText("——.————");
        overlay.addView(egpPriceView);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        int savedX = p.getInt("x", dp(8));
        int savedY = p.getInt("y", dp(52));

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );

        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = savedX;
        overlayParams.y = savedY;

        wm.addView(overlay, overlayParams);
        installDragHandler();
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(11);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setIncludeFontPadding(false);
        return v;
    }

    private TextView priceText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(235, 238, 244));
        v.setTextSize(13);
        v.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        v.setIncludeFontPadding(false);
        return v;
    }

    private TextView spacer(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setIncludeFontPadding(false);
        return v;
    }

    private void installDragHandler() {
        overlay.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float downX, downY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = overlayParams.x;
                        startY = overlayParams.y;
                        downX = event.getRawX();
                        downY = event.getRawY();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        overlayParams.x = startX + Math.round(event.getRawX() - downX);
                        overlayParams.y = startY + Math.round(event.getRawY() - downY);
                        try { wm.updateViewLayout(overlay, overlayParams); } catch (Exception ignored) {}
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putInt("x", overlayParams.x)
                                .putInt("y", overlayParams.y)
                                .apply();
                        return true;
                }
                return false;
            }
        });
    }

    private WebView createHiddenWebView(String url) {
        WebView webView = new WebView(this);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(false);
        s.setBlockNetworkImage(true);
        s.setUserAgentString(s.getUserAgentString() + " FXOverlay/2.0");

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String pageUrl) {
                view.evaluateJavascript(
                        "(function(){var b=[...document.querySelectorAll('button')].find(x=>/accept|agree|موافق|قبول/i.test(x.innerText||''));if(b)b.click();})()",
                        null
                );
            }
        });

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                2, 2,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;
        params.alpha = 0.01f;

        wm.addView(webView, params);
        webView.loadUrl(url);
        return webView;
    }

    private void pollWebView(WebView webView, boolean eurUsd) {
        if (destroyed || webView == null) return;

        String range = eurUsd
                ? "(n>0.70&&n<1.80)"
                : "(n>20&&n<100)";

        String js =
                "(function(){" +
                "var e=document.querySelector('[data-test=\"instrument-price-last\"]')" +
                "||document.querySelector('[data-test=\"instrument-price-last-value\"]');" +
                "if(e){" +
                " var t=(e.innerText||e.textContent||'').trim();" +
                " if(/^[0-9]+[.,][0-9]{1,6}$/.test(t))return t;" +
                "}" +
                "var all=document.querySelectorAll('span,div');" +
                "for(var i=0;i<all.length&&i<2800;i++){" +
                " var t2=(all[i].textContent||'').trim();" +
                " if(/^[0-9]+[.,][0-9]{1,6}$/.test(t2)){" +
                "   var n=parseFloat(t2.replace(',','.'));" +
                "   var r=all[i].getBoundingClientRect();" +
                "   if(" + range + "&&r.width>15&&r.height>8&&r.top<1000)return t2;" +
                " }" +
                "}" +
                "return '';" +
                "})()";

        try {
            webView.evaluateJavascript(js, value -> {
                String p = normalizeJsResult(value);
                if (isPlausible(p, eurUsd)) {
                    if (eurUsd) lastEurWebPriceAt = System.currentTimeMillis();
                    else lastEgpWebPriceAt = System.currentTimeMillis();

                    setPrice(eurUsd, p);
                }
            });
        } catch (Exception ignored) {}
    }

    private String normalizeJsResult(String v) {
        if (v == null || "null".equals(v)) return "";

        String p = v.trim();

        if (p.startsWith("\"") && p.endsWith("\"") && p.length() >= 2) {
            p = p.substring(1, p.length() - 1);
        }

        p = p.replace("\\n", "")
                .replace("\\u00a0", "")
                .replace(" ", "");

        return p.replace(',', '.');
    }

    private boolean isPlausible(String p, boolean eurUsd) {
        if (p == null || !p.matches("[0-9]+\\.[0-9]{1,6}")) return false;

        try {
            double d = Double.parseDouble(p);
            return eurUsd
                    ? d > 0.70 && d < 1.80
                    : d > 20.0 && d < 100.0;
        } catch (Exception e) {
            return false;
        }
    }

    private void setPrice(boolean eurUsd, String p) {
        if (!isPlausible(p, eurUsd)) return;

        main.post(() -> {
            TextView target = eurUsd ? eurPriceView : egpPriceView;
            if (target == null) return;

            String previous = eurUsd ? lastEurPrice : lastEgpPrice;
            int color = Color.rgb(235, 238, 244);

            if (previous != null) {
                try {
                    double oldV = Double.parseDouble(previous);
                    double newV = Double.parseDouble(p);

                    if (newV > oldV) color = Color.rgb(62, 220, 120);
                    else if (newV < oldV) color = Color.rgb(255, 90, 90);
                } catch (Exception ignored) {}
            }

            if (eurUsd) lastEurPrice = p;
            else lastEgpPrice = p;

            target.setText(p);
            target.setTextColor(color);

            String eur = lastEurPrice == null ? "…" : lastEurPrice;
            String egp = lastEgpPrice == null ? "…" : lastEgpPrice;
            updateNotification("EUR/USD " + eur + "  |  USD/EGP " + egp);
        });
    }

    private void fetchViaHttpFallback(String sourceUrl, boolean eurUsd) {
        io.execute(() -> {
            HttpURLConnection c = null;

            try {
                URL url = new URL(sourceUrl);
                c = (HttpURLConnection) url.openConnection();

                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                c.setRequestProperty(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36"
                );
                c.setRequestProperty("Accept-Language", "ar,en-US;q=0.8,en;q=0.7");
                c.setRequestProperty(
                        "Accept",
                        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
                );

                StringBuilder html = new StringBuilder();

                try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
                    String line;
                    while ((line = br.readLine()) != null && html.length() < 1_800_000) {
                        html.append(line).append('\n');
                    }
                }

                String p = parsePriceFromHtml(html.toString(), eurUsd);
                if (p != null) setPrice(eurUsd, p);

            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private String parsePriceFromHtml(String html, boolean eurUsd) {
        if (html == null || html.isEmpty()) return null;

        Pattern[] patterns = new Pattern[]{
                Pattern.compile(
                        "data-test=\\\"instrument-price-last\\\"[^>]*>\\s*([0-9]+[.,][0-9]{1,6})\\s*<",
                        Pattern.CASE_INSENSITIVE
                ),
                Pattern.compile(
                        "instrument-price-last[^>]*>\\s*([0-9]+[.,][0-9]{1,6})\\s*<",
                        Pattern.CASE_INSENSITIVE
                ),
                Pattern.compile(
                        "\\\"last\\\"\\s*:\\s*\\\"?([0-9]+[.,][0-9]{1,6})",
                        Pattern.CASE_INSENSITIVE
                ),
                Pattern.compile(
                        "\\\"last_close\\\"\\s*:\\s*\\\"?([0-9]+[.,][0-9]{1,6})",
                        Pattern.CASE_INSENSITIVE
                )
        };

        for (Pattern pattern : patterns) {
            Matcher m = pattern.matcher(html);
            if (m.find()) {
                String p = m.group(1).replace(',', '.');
                if (isPlausible(p, eurUsd)) return p;
            }
        }

        return null;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID,
                    "FX Overlay",
                    NotificationManager.IMPORTANCE_LOW
            );

            c.setDescription("Keeps EUR/USD and USD/EGP floating prices active");
            c.setShowBadge(false);

            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(c);
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);

        PendingIntent pi = PendingIntent.getActivity(
                this,
                0,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return b.setContentTitle("FX Overlay")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        destroyed = true;
        main.removeCallbacksAndMessages(null);
        io.shutdownNow();

        destroyWebView(eurWebView);
        destroyWebView(egpWebView);

        if (wm != null) {
            try {
                if (overlay != null) wm.removeView(overlay);
            } catch (Exception ignored) {}
        }

        super.onDestroy();
    }

    private void destroyWebView(WebView view) {
        if (view == null) return;

        try { view.stopLoading(); } catch (Exception ignored) {}

        if (wm != null) {
            try { wm.removeView(view); } catch (Exception ignored) {}
        }

        try { view.destroy(); } catch (Exception ignored) {}
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
