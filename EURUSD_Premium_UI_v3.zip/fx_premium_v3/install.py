#!/usr/bin/env python3
from pathlib import Path
import shutil
root=Path.cwd()
target=root/'app/src/main/java/com/almuhandis/eurusdoverlay/PremiumScreen.java'
main=target.with_name('MainActivity.java')
if not main.exists() or 'PremiumScreen.render' not in main.read_text():
    raise SystemExit('V2 must be installed first; MainActivity is not compatible. Nothing changed.')
fonts=root/'app/src/main/assets/fonts'
if not all((fonts/n).exists() for n in ('Cairo-Regular.ttf','Cairo-Bold.ttf')):
    raise SystemExit('Cairo fonts are missing; install V2 first. Nothing changed.')
if target.exists(): shutil.copy2(target,target.with_suffix('.java.v2-backup'))
shutil.copy2(Path(__file__).with_name('PremiumScreen.java'),target)
print('V3 installed. MainActivity and OverlayService were not modified.')
