V3 UI replacement for the existing EURUSD Overlay project.
Requires the previously installed V2 and Cairo font assets.
Install from repository root:
  unzip -o EURUSD_Premium_UI_v3.zip -d /tmp
  python3 /tmp/fx_premium_v3/install.py
  git add app/src/main/java/com/almuhandis/eurusdoverlay/PremiumScreen.java
  git commit -m 'Refine premium FX interface V3'
  git push origin main
The reference is an illustrative mockup, not a pixel-identical production layout.
Preview numbers are illustrative; overlay live quotes remain unchanged.
